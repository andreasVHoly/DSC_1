/**
 * Author: Anthony Sulistio
 * Date: April 2003
 */

NOTE: When you open "output.txt" file, it tells you that this example creates
      8 Gridlets. Then sends one Gridlet from "Example3" entity to "Test"
      entity. The "Test" entity modifies the status of the Gridlet into
      "Gridlet.SUCCESS". Therefore, the output is correct as expected with all
      the Gridlets have the same status.

